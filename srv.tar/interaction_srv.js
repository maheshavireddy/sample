const cds = require("@sap/cds");
// const jsonData = require('../app/require/webapp/model/data.json');
// console.log(jsonData)
const fs = require('fs');
const filePath ='app/require/webapp/model/data.json';
module.exports = srv => {
    /// Seed crud 
    srv.before("validation", async (req) => {
        debugger;
        console.log("This is before validation function execution");
    });
    srv.on("validation", async (req, res) => {
        if (req.data.flag === "C") {
            try {
                debugger;
                const obj = JSON.parse(req.data.Obj); // seed table data in obj with all 
                const obj2 = JSON.parse(req.data.Obj2)
                // const C = obj2.length
                // const CL = ("CP_ITEM").length
                const duplicates = obj2.forEach( async (element) => {
                    const obj1 = {
                        "ID": obj.ID  ,
                        "PRODUCT": obj.PRODUCT_ID,
                        "CHAR_NUM": element.CHARVAL_NUM,
                        "CHAR_NUM_VAL": element.description
                    }
                    await cds.run(INSERT.into("CP_ITEM").entries(obj1)); 
                });
                await cds.run(INSERT.into("CP_SEEDTABLE").entries(obj));
                // await cds.run(INSERT.into("CP_ITEM").entries(obj2))
                const result = { message: "Successfully Created " }
                return result;
            } catch (error) {
                console.error(error);
                return error;
            }
        }
       
        if (req.data.flag === "D") {
            try {
                debugger;
                const obj = JSON.parse(req.data.Obj);
                await cds.run(DELETE.from("CP_INTERACTIONS_HEADER").where({ ID: req.data.Obj }));

                const result = { message: "Successfully Deleted " }
                return result;
            } catch (error) {
                console.log(error)
            }
        }
        if (req.data.flag === "U") {
            try {
                debugger;
                const obj = JSON.parse(req.data.Obj); // seed table data in obj with all 
                const obj2 = JSON.parse(req.data.Obj2)
                // const C = obj2.length
                // const CL = ("CP_ITEM").length
                const duplicates = obj2.forEach( async (element) => {
                    const obj1 = {
                        "ID": obj.ID  ,
                        "PRODUCT": obj.PRODUCT_ID,
                        "CHAR_NUM": element.CHARVAL_NUM,
                        "CHAR_NUM_VAL": element.CHAR_NUM_VAL_DES
                    }
                    await cds.run(INSERT.into("CP_ITEM").entries(obj1));
                    
                });
               
                await cds.run(INSERT.into("CP_SEEDTABLE").entries(obj));
               
                // await cds.run(INSERT.into("CP_ITEM").entries(obj2))
                const result = { message: "Successfully Copy Created " }
                return result;
            } catch (error) {
                console.error(error);
                return error;
            }
        }
    });
    srv.after("validation", res => {
        debugger;
        console.error("This is after validation function is completed");
    });
////validator
    srv.before("Validator", async  req => {
        debugger;
        console.log("This is before validation function execution");
        
    })
    srv.on("Validator", async (req, res) => {
        if (req.data.flag === "C") {
            try {
                debugger;
                const obj = JSON.parse(req.data.Obj); // seed Order  data in obj with all 
                const Cobj = {
                    "ID": obj.ID,
                    "UNIQUE_ID":obj.UNIQUE_ID,
                    "PRODUCT":obj.PRODUCT,
                    "DESCRIPTION":obj.DESCRIPTION,
                    "QUANTITY":obj.QUANTITY,
                    "DATE":obj.DATE,
                    "CREATED_DATE": new Date().toLocaleDateString(),
                    "CREATED_BY": req.headers["x-username"]
                }
                await cds.run(INSERT.into("CP_ORDERTABLE").entries(Cobj));
                const result = { message: "Successfully  Order Created " }
                return result;
            } catch (error) {
                console.error(error);
                return error;
            }
        }
        if (req.data.flag === "E"){
            try{
                debugger;
           const obj = JSON.parse(req.data.Obj);
            await cds.run(UPDATE ("CP_SEEDTABLE",{ID: obj.ID}).with ({
                ID:obj.ID,
                ACTIVE: obj.ACTIVE,
                }));
            const result = { message: "Successfully Updated " }
            return result;
            } catch (error){
                console.log(error)
            }
        }
        if (req.data.flag === "O") {
            try {
                debugger;
                const obj = JSON.parse(req.data.Obj); // seed Order  data in obj with all 
                const OC = obj.forEach(async (element) =>{
                    const SOC = {
                        "ID": element.ID,
                        "UNIQUE_ID":element.UNIQUE_ID,
                        "PRODUCT":element.PRODUCT,
                        "DESCRIPTION":obj.DESCRIPTION,
                        "QUANTITY":element.QUANTITY,
                        "DATE":element.DATE,
                        "CREATED_DATE": new Date().toLocaleDateString(),
                        "CREATED_BY": req.headers["x-username"]
                    }
                    await cds.run(INSERT.into("CP_ORDERTABLE").entries(SOC));
                })
                const result = { message: "Successfully  Order Created " }
                return result;
            } catch (error) {
                console.error(error);
                return error;
            }
        }
    });

    srv.after("Validator", res => {
        debugger;
        console.error("This is after Validator function is Completed")
    })
    srv.before("CRUD", async  req => {
        debugger;
        console.log("This is before CRUD function execution");
        
    })
    srv.on("CRUD", async(req,res) =>{
            if(req.data.flag === "CR"){
                try{
                    const obj = JSON.parse(req.data.Obj); 
                    fs.readFile(filePath, 'utf8', (err, data) => {
                        if (err) {
                            console.error('Error reading file:', err.message);
                            return;
                        }
                        try {
                            const existingData = JSON.parse(data);
                            existingData.push(obj);
                            const updatedJSON = JSON.stringify(existingData, null, 2);
                            fs.writeFile(filePath, updatedJSON, 'utf8', (writeErr) => {
                                if (writeErr) {
                                    console.error('Error writing file:', writeErr.message);
                                } else {
                                    console.log('Object appended successfully.');
                                    return ({ message: 'Created  successfully' });
                                }
                            });
                        }catch (parseError) {
                            console.error('Error parsing JSON:', parseError.message);
                    }
                    });
                    const result = { message: "Successfully   Created  " }
                    return result;
                }
                catch (error) {
                    console.log(error)
                } 
            }
        
        if(req.data.flag === "UPC"){
            // try{
                const obj1 = JSON.parse(req.data.Obj); 
                fs.readFile(filePath, 'utf8', (err, data) => {
                    if (err) {
                        console.error('Error reading file:', err.message);
                        res.status(500).json({ error: 'Error reading file' });
                        return;
                    }
                    try {
                        const existingData = JSON.parse(data);
                        const updatedData = existingData.map(obj => {
                            if (obj.PAGEID === obj1.PAGEID ) {
                                return obj1;
                            }
                            return obj;
                        });
                        const updatedJSON = JSON.stringify(updatedData, null, 2);
                        fs.writeFile(filePath, updatedJSON, 'utf8', (writeErr) => {
                            if (writeErr) {
                                console.error('Error writing file:', writeErr.message);
                                // res.status(500).json({ error: 'Error writing file' });
                            } 
                            else {
                                console.log('Object edited successfully.');
                                return ({ message: 'Object edited successfully' });
                            }
                        });
                    }
                    catch (parseError) {
                        console.error('Error parsing JSON:', parseError.message);
                        return ({ error: 'Error parsing JSON' });
                    }
                });
                const result = { message: "Successfully Updated " }
                return result;
            // }
        }
        if (req.data.flag === "DEL") {
            try {
                debugger;
                const obj2 = JSON.parse(req.data.Obj);
                fs.readFile(filePath, 'utf8', (err, data) => {
                    if (err) {
                        console.error('Error reading file:', err.message);
                        res.status(500).json({ error: 'Error reading file' });
                        return;
                    }
                    try {
                        const existingData = JSON.parse(data);
                        const updatedData = existingData.filter(obj => obj.PAGEID !== obj2.PAGEID);
            
                        const updatedJSON = JSON.stringify(updatedData, null, 2);
                        fs.writeFile(filePath, updatedJSON, 'utf8', (writeErr) => {
                            if (writeErr) {
                                console.error('Error writing file:', writeErr.message);
                            
                            } else {
                                console.log('Object deleted successfully.');
                                return ({ message: 'Object deleted successfully' });
                            }
                        });
                    } catch (parseError) {
                        console.error('Error parsing JSON:', parseError.message);
                        return ({ error: 'Error parsing JSON' });
                    }
                });

                const result = { message: "Successfully Deleted " }
                return result;
            } 
            catch (error) {
                console.log(error)
            }
        }
        srv.after("CRUD", res => {
            debugger;
            console.error("This is after CRUD function is Completed")
        })
    })
    srv.before("CURD", async  req => {
        debugger;
        console.log("This is before CURD function execution");
        
    })
    srv.on("CURD", async(req,res) =>{
        const object = JSON.parse(req.data.Obj);
        if(req.data.flag === "CREATE"){
            // await cds.run('' .push(object))
            // await cds.run(INSERT.into('data.json').entries(object))
            const result = { message: "Successfully   Created  " }
            return result;
        }
        else{
            console.error('Error parsing JSON:', parseError.message);
        }
    })
    srv.before("pdfstore", async (req) => {
        debugger;
        console.log("This is before function execution");
    });
    srv.on("pdfstore", async (req, res) => {
        if (req.data.flag === "save"){
            try {
                debugger;
                const obj = JSON.parse(req.data.Obj);
                await cds.run(INSERT.into("CP_PDFSTORE").entries({ID:obj.ID,NAME:obj.NAME,URL:obj.URL}));
                const result = { message: "Successfully Created " }
                return result;
            } catch (error) {
                console.error(error);
                return error;
            }
        }
        if (req.data.flag === "PDFDELETE") {
            try {
                debugger;
                const obj = JSON.parse(req.data.Obj);
                await cds.run(DELETE.from("CP_PDFSTORE").where({ ID: obj.ID }));

                const result = { message: "Successfully Deleted " }
                return result;
            } catch (error) {
                console.log(error)
            }
        }
        });
    srv.after("pdfstore", res => {
        debugger;
        console.error("This is after  function is completed");
    });

srv.before("Images" , async (req)=>{
    debugger;
    console.log("This is before function execution");
})
srv.on("Images", async (req, res) => {
    if (req.data.flag === "PNG"){
        try {
            debugger;
            const obj = JSON.parse(req.data.Obj);
            await cds.run(INSERT.into("CP.Images").entries({ID:obj.ID,NAME:obj.NAME,URL:obj.URL}));
            const result = { message: "Successfully Created " }
            return result;
        } catch (error) {
            console.error(error);
            return error;
        }
    }
    });
    srv.after("Images", res => {
        debugger;
        console.error("This is after  function is completed");
    });



}