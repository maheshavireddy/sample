sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/PDFViewer",
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller,JSONModel,PDFViewer) {
        "use strict";
        var that
        var items =  []
        var oCell
        var aModel
        var data
        return Controller.extend("uploads.controller.View1", {
            onInit: function () {
                that = this
                // var oModel = that.getOwnerComponent().getModel("Odata");
                // var oTable = that.getView().byId("tab1");
                // oModel.read('/Interaction_pdfstore', {
                //     success: function(Odata) {
                //         oMain = Odata.results;
                //         var aModel = new sap.ui.model.json.JSONModel();
                //             aModel.setData({
                //                 items:[oMain]
                //             })
                //             that.getView().setModel(aModel);
                //     }
                // })
                // that.getView().byId("tab1").setModel(oModel);
                // // oTable.getView().setModel(oModel)
                 	
           
                           
            },
            onAfterRendering: function() {
                var oModel = this.getOwnerComponent().getModel("Odata");
                var oTable = this.getView().byId("tab1");
                
                
                oModel.read('/Interaction_pdfstore', {
                    success: function(aResults) {
                        var oJSONModel = new sap.ui.model.json.JSONModel(aResults);
                        oTable.setModel(oJSONModel);
                    
                        if (aResults.results.length > 0 ) {
                            data = aResults.results.length 
                            aModel = new sap.ui.model.json.JSONModel(aResults.results);
                       
                            that.getView().byId("tab1").setModel(aModel);                           
                        } else {
                            console.log("No data in model.");
                        }
                    },
                    error: function(error) {
                        console.log(error);
                    }
                });
            },
            

            Save: function(){
                if (!that.newDialog) {
                    that.newDialog = sap.ui.xmlfragment("uploads.view.CreateDialog", that);
                } 
              
                that.newDialog.open();
                
            },
            onCancel: function(){
                that.newDialog.close()
            },
            OnSave:function(){
                var name = sap.ui.getCore().byId("NAME").getValue();
                // var id = Math.random()
                    var fileupload = this.getView().byId("pdfupload");
                    var file  = fileupload.oFileUpload.files[0];
                    
                    var reader = new FileReader();
                    reader.onload = function(e){
                        var base64 =  e.target.result;
                        var bytes = new Uint16Array(reader.result);
                        var oObj = {
                            ID: data + 1,
                            NAME  : name ,
                            URL: base64
    
                        }
                        var oModel = that.getOwnerComponent().getModel("Odata");
                        oModel.callFunction("/pdfstore", {
                            method : "GET",
                            urlParameters: {
                                flag: "save",
                                Obj: JSON.stringify(oObj)
                                
                            },
                            success: function (oData, _response) {
                                // var message = _response.data.validation.message;
                                // sap.m.MessageToast.show(message);
                               
                                that.newDialog.close()
                                that.onAfterRendering()
                               
                            },
                            error: function (e) {
                                sap.m.MessageToast.show(e);
                            }
                        })
                    
                       
                    }
                    reader.readAsDataURL(file)
                    
             
                 

                },
                onPdfUpload:function(){
                    var fileupload = this.getView().byId("pdfupload");
                    var file  = fileupload.oFileUpload.files[0];
                    var url = URL.createObjectURL(file);
                    
                    
                    window.open(url,"_blank")
                },
                showPdf:function(oEvent){
                    var sBase = oEvent.getSource().getBindingContext().getObject().URL
                    var url = this.base64toblob(sBase)
                    // var url = URL.createObjectURL(cBase)

                    window.open(url,"_blank")

                    
                },
                base64toblob:function(base){
                    var sByteString = atob(base.split(',')[1]);
                    var mimeString = base.split(',')[0].split(':')[1].split(';')[0]
                    const mime = "application/pdf";
                    var aR = new ArrayBuffer(sByteString.length);
                    var cArray = new Uint8Array(aR);
                    for (var i = 0; i < sByteString.length; i++) {
                        cArray[i] = sByteString.charCodeAt(i);
                    }
                    var blob = new Blob([aR], {type:mime});
                    return URL.createObjectURL(blob)
                }





                   
      });
     });
     
